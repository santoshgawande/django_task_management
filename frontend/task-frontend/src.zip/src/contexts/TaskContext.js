import { createContext, useContext, useReducer } from 'react';

const TaskState = createContext();
const TaskDispatch = createContext();

function taskReducer(state, action) { 
  
 }

export function TaskProvider({ children }) {
  const [tasks, dispatch] = useReducer(taskReducer, []);
  return (
    <TaskState.Provider value={tasks}>
      <TaskDispatch.Provider value={dispatch}>
        {children}
      </TaskDispatch.Provider>
    </TaskState.Provider>
  );
}

// Only hooks and context – no JSX here
export const useTasks = () => useContext(TaskState);
export const useTaskDispatch = () => useContext(TaskDispatch);