import React from 'react';
import { TaskProvider as ContextProvider } from '../contexts/taskContext';

export default function TaskProvider({ children }) {
  // This file only exports a component
  return <ContextProvider>{children}</ContextProvider>;
}
